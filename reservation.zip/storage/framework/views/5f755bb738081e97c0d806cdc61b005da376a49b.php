<?php $__env->startSection('content'); ?>



<div class="container">
    <div class="row">
        <h3>Reservation List</h3></div><br>


       <span style="float:right;"> <a class="btn btn-primary" href="<?php echo e(URL::to('/')); ?>/reservation/create" role="button">Add</a></span>

        <table id="example" class="table table-striped table-bordered" style="width:100%">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>Number People</th>
                        <th>Date</th>
                        <th>Time Slot</th>
                        <th>Number Table</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $reservations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reservation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($reservation->name); ?></td>
                        <td><?php echo e($reservation->email); ?></td>
                        <td><?php echo e($reservation->phone); ?></td>
                        <td><?php echo e($reservation->number_people); ?></td>
                        <td><?php echo e($reservation->date); ?></td>
                        <td><?php echo e($reservation->time_slot); ?></td>
                        <td><?php echo e($reservation->table_number); ?></td>
                        <td> 
                        <a class="btn btn-success" href="<?php echo e(route('reservation.show', $reservation->id)); ?>" role="button">view</a>
                         <a class="btn btn-info" href="<?php echo e(route('reservation.edit', $reservation->id)); ?>" role="button">Edit</a>
                        


                                <form action="<?php echo e(route('reservation.destroy', $reservation->id)); ?>" method="POST" onsubmit="return confirm('<?php echo e(trans('global.areYouSure')); ?>');" style="display: inline-block;">
                                    <input type="hidden" name="_method" value="DELETE">
                                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                    <input type="submit" class="btn btn-danger" value="Delete">
                                </form>




                    </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                  
                </tbody>
              
            </table>
</div>
</div>

<?php $__env->stopSection(); ?>
<script>
    $(document).ready(function() {
    $('#example').DataTable();
} );
</script>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\reservation\resources\views/reservation/index.blade.php ENDPATH**/ ?>