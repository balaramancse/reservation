<!DOCTYPE html>

    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">

    </head>
    <body>
 <h1>hi</h1>
    </body>
</html>
<?php /**PATH D:\xampp\htdocs\reservation\resources\views/email/email.blade.php ENDPATH**/ ?>