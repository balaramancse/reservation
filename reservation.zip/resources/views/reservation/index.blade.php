@extends('layouts.app')

@section('content')



<div class="container">
    <div class="row">
        <h3>Reservation List</h3></div><br>


       <span style="float:right;"> <a class="btn btn-primary" href="{{URL::to('/')}}/reservation/create" role="button">Add</a></span>

        <table id="example" class="table table-striped table-bordered" style="width:100%">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>Number People</th>
                        <th>Date</th>
                        <th>Time Slot</th>
                        <th>Number Table</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($reservations as $reservation)
                    <tr>
                        <td>{{$reservation->name}}</td>
                        <td>{{$reservation->email}}</td>
                        <td>{{$reservation->phone}}</td>
                        <td>{{$reservation->number_people}}</td>
                        <td>{{$reservation->date}}</td>
                        <td>{{$reservation->time_slot}}</td>
                        <td>{{$reservation->table_number}}</td>
                        <td> 
                        <a class="btn btn-success" href="{{ route('reservation.show', $reservation->id) }}" role="button">view</a>
                         <a class="btn btn-info" href="{{ route('reservation.edit', $reservation->id) }}" role="button">Edit</a>
                        


                                <form action="{{ route('reservation.destroy', $reservation->id) }}" method="POST" onsubmit="return confirm('{{ trans('global.areYouSure') }}');" style="display: inline-block;">
                                    <input type="hidden" name="_method" value="DELETE">
                                    <input type="hidden" name="_token" value="{{ csrf_token() }}">
                                    <input type="submit" class="btn btn-danger" value="Delete">
                                </form>




                    </td>
                    </tr>
                    @endforeach
                    
                  
                </tbody>
              
            </table>
</div>
</div>

@endsection
<script>
    $(document).ready(function() {
    $('#example').DataTable();
} );
</script>