@extends('layouts.app')

@section('content')



<div class="container">
    <div class="row">

      <span style="float:right;"> <a class="btn btn-primary" href="{{URL::to('/')}}/reservation" role="button">back</a></span>

       
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.1.0/css/all.css" integrity="sha384-lKuwvrZot6UHsBSfcMvOkWwlCMgc0TaWr+30HWe3a4ltaBwTZhyTEggF5tJv8tbt" crossorigin="anonymous">
<div class="container">

    <div class="row justify-content-center">
        <div class="col-12 col-md-8 col-lg-6 pb-5">


                    <!--Form with header-->

                    <form action="{{ route("reservation.update", [$reservation->id]) }}" method="POST">
                        @csrf
                          @method('PUT')

                        <div class="card border-primary rounded-0">
                            <div class="card-header p-0">
                                <div class="bg-info text-white text-center py-2">
                                    <h3></i>Reservation Create</h3>
                                   
                                </div>
                            </div>
                            <div class="card-body p-3">

                                <!--Body-->
                                <div class="form-group">
                                    <div class="input-group mb-2">
                                        <div class="input-group-prepend">
                                            <div class="input-group-text"><i class="fa fa-user text-info"></i></div>
                                        </div>
                                        <input type="text" class="form-control" id="nombre" name="name" placeholder="Name" required value="{{$reservation->name}}">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="input-group mb-2">
                                        <div class="input-group-prepend">
                                            <div class="input-group-text"><i class="fa fa-envelope text-info"></i></div>
                                        </div>
                                        <input type="email" class="form-control" id="nombre" name="email" placeholder="email" required value="{{$reservation->email}}">
                                    </div>
                                </div>

                                <div class="form-group">
                                    <div class="input-group mb-2">
                                        <div class="input-group-prepend">
                                            <div class="input-group-text"><i class="fa fa-envelope text-info"></i></div>
                                        </div>
                                        <input type="number" class="form-control" id="nombre" name="phone" placeholder="phone" required value="{{$reservation->phone}}">
                                    </div>
                                </div>

                                <div class="form-group">
                                    <div class="input-group mb-2">
                                        <div class="input-group-prepend">
                                            <div class="input-group-text"><i class="fa fa-envelope text-info"></i></div>
                                        </div>
                                        <input type="number" class="form-control" id="nombre" name="number_people" placeholder="Number People" required value="{{$reservation->number_people}}">
                                    </div>
                                </div>


                                  <div class="form-group">
                                    <div class="input-group mb-2">
                                        <div class="input-group-prepend">
                                            <div class="input-group-text"><i class="fa fa-envelope text-info"></i></div>
                                        </div>
                                        <input type="date" class="form-control" id="nombre" name="date" placeholder="Date" required value="{{$reservation->date}}">
                                    </div>
                                </div>



                                  <div class="form-group">
                                    <div class="input-group mb-2">
                                        <div class="input-group-prepend">
                                            <div class="input-group-text"><i class="fa fa-envelope text-info"></i></div>
                                        </div>
                               <select  name ="time_slot" class="form-control"> 
                                        <option value ="0"> Please select Time Slot</option>
                                        <option value = "7 - 8PM" >7 - 8AM</option>
                                        <option value = "8 - 9AM" >8 - 9AM</option>
                                        <option value = "9 - 10AM" >9 - 10AM</option>
                                        <option value = "10 -11AM" >10 - 11AM</option>
                                        <option value = "11 - 12PM" >11 - 12PM</option>
                                        <option value = "12 - 1PM" >12 - 1PM</option>
                                     
                                        </select>
                                    </div>
                                </div>


                                     <div class="form-group">
                                    <div class="input-group mb-2">
                                        <div class="input-group-prepend">
                                            <div class="input-group-text"><i class="fa fa-envelope text-info"></i></div>
                                        </div>
                                       <select  name ="table_number" class="form-control"> 
                                        <option value ="0"> Please select No Table</option>
                                        <option value = "1" >1</option>
                                        <option value = "2" >2</option>
                                        <option value = "3" >3</option>
                                        <option value = "4" >4</option>
                                        <option value = "5" >5</option>
                                        <option value = "6" >6</option>
                                        <option value = "7" >7</option>
                                        <option value = "8" >8</option>
                                        <option value = "9" >9</option>
                                        <option value = "10" >10</option>
                                        </select>
                                    </div>
                                </div>



                             

                                <div class="text-center">
                                    <input type="submit" value="Submit" class="btn btn-info btn-block rounded-0 py-2">
                                </div>
                            </div>

                        </div>
                    </form>
                    <!--Form with header-->


                </div>
    </div>
</div>
</div>
</div>

@endsection
<script>
    $(document).ready(function() {
    $('#example').DataTable();
} );
</script>