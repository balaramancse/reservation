<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Reservation;
use Session;
use Mail;
use DB;
class ReservationController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {


        $reservations = Reservation::all();     
          Session::flash('message', 'Successfully created information'); 
        return view('reservation.index', compact('reservations'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('reservation.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

    $a = DB::table('reservations')->where('date',$request->date)->where('time_slot',$request->time_slot)->where('table_number',$request->table_number)->first();
 
        if($a)
        {
           
            return back()->with('success','Already date and timeslot is alter for someone');
        }

        else
        {
            $post = new Reservation;
            $post->name = $request->input('name');
            $post->email = $request->input('email');
            $post->phone = $request->input('phone');
            $post->number_people = $request->input('number_people');
            $post->date = $request->input('date');
            $post->time_slot = $request->input('time_slot');
            $post->table_number = $request->input('table_number');
            $post->save();

          /*  $data['email']      = 'balainfo90@gmail.com';

            Mail::send('email.email', $data, function($message) use ($data)
            {    
                 $message->to($data['email']); 
                 $message->subject('Email Confirmation');
                 $message->from('balainfo90@gmail.com', 'World of construction');    
            });
            */

                return redirect()->route('reservation.index');

        }



           
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        return "show info";
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
         $reservation = Reservation::find($id);
       return view('reservation.edit', compact('reservation'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {

           
            $post = Reservation::where('id', '=', $id)->first();
            $post->name = $request->input('name');
            $post->email = $request->input('email');
            $post->phone = $request->input('phone');
            $post->number_people = $request->input('number_people');
            $post->date = $request->input('date');
            $post->time_slot = $request->input('time_slot');
            $post->table_number = $request->input('table_number');
            $post->save();
        return redirect()->route('reservation.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $deletesocial=Reservation::where('id',$id)->delete();
        
        return redirect()->route('reservation.index');
    }
}
